﻿namespace MiniEshopBlazor.Services
{
    public class AuthService
    {
        private const string AdminUsername = "admin";
        private const string AdminPassword = "1234";

        public bool IsLoggedIn { get; private set; }

        public bool Login(string username, string password)
        {
            if (username == AdminUsername && password == AdminPassword)
            {
                IsLoggedIn = true;
                return true;
            }

            return false;
        }

        public void Logout()
        {
            IsLoggedIn = false;
        }
    }
}

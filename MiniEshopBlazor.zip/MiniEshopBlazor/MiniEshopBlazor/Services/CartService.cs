﻿using MiniEshopBlazor.Models;

namespace MiniEshopBlazor.Services
{
    public class CartService
    {
        private readonly List<CartItem> _items = new();

        public IReadOnlyList<CartItem> Items => _items;

        public void Add(Product product)
        {
            var existing = _items.FirstOrDefault(i => i.Product.Id == product.Id);
            if (existing != null)
                existing.Quantity++;
            else
                _items.Add(new CartItem { Product = product, Quantity = 1 });
        }

        public void RemoveOne(string productId)
        {
            var existing = _items.FirstOrDefault(i => i.Product.Id == productId);
            if (existing == null) return;

            existing.Quantity--;
            if (existing.Quantity <= 0)
                _items.Remove(existing);
        }

        public void RemoveAll(string productId)
        {
            var existing = _items.FirstOrDefault(i => i.Product.Id == productId);
            if (existing != null)
                _items.Remove(existing);
        }

        public void Clear() => _items.Clear();

        public decimal Total() => _items.Sum(i => i.Product.Price * i.Quantity);
    }
}

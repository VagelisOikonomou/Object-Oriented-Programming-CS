﻿namespace MiniEshopBlazor.Models
{
    public class Admin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
